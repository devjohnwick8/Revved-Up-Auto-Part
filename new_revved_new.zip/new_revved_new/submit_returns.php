  <?php include 'includes/header.php'; ?>
  <!-- banner start -->
  <section class="inner_banner">
    <div class="container">
      <!--       <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner_text black_bg">
            <h1>Contact Us</h1>
          </div>
        </div>
      </div> -->
    </div>
  </section>
  <!-- banner end -->
  <!-- BEGIN Contact Us -->
  <section id="testimonials">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="gettouch">
            <span>Returns Form</span>
            <p>TELL US HOW WE CAN HELP.</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="commentSection ask_quiestion">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <form class="row g-3">
              <div class="col-md-6">
                  <label for="inputEmail4" class="form-label">Nature of Claim</label>
                  <select class="form-control">
                    <option>Select an Option</option>
                    <option>Pre-order Question</option>
                    <option>Order status / Request Tracking</option>
                    <option>New Item Return / Cancellation</option>
                    <option>Shipping Damage</option>
                    <option>Warranty Claim </option>
                    <option>Fitment Issues</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label for="Name" class="form-label">Order ID </label>
                  <input type="number" class="form-control" id="Name">
                </div>
                <div class="col-md-6">
                  <label for="Name" class="form-label">First Name</label>
                  <input type="text" class="form-control" id="Name">
                </div>
                <div class="col-md-6">
                  <label for="Name" class="form-label">Last Name</label>
                  <input type="text" class="form-control" id="Name">
                </div>
                <div class="col-md-6">
                  <label for="email" class="form-label">*EMAIL</label>
                  <input type="email" class="form-control" id="email">
                </div>
                <div class="col-md-6">
                  <label for="Number" class="form-label">Phone Number</label>
                  <input type="tel" class="form-control" id="Number">
                </div>
                <div class="col-12">
                  <div class="form-floating">
                    <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 150px"></textarea>
                    <label for="floatingTextarea2">*DESCRIPTION</label>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- END Contact Us -->
  <?php include 'includes/footer.php'; ?>