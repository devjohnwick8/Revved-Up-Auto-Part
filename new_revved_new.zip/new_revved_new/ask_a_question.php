  <?php include 'includes/header.php'; ?>
  <!-- banner start -->
  <section class="inner_banner">
    <div class="container">
      <!--       <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner_text black_bg">
            <h1>Contact Us</h1>
          </div>
        </div>
      </div> -->
    </div>
  </section>
  <!-- banner end -->
  <!-- BEGIN Contact Us -->
  <section class="my_link">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <h3>You Can Easily Find The Answers</h3>
          <!--<p>A place you can easily find answers and submit return tickets</p>-->
          <!--<p> <small>Don't see what you're looking for?</small> </p>-->
          <div class="link_search">
            <div class="my_sear">
              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Search">
              <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </div>
          </div>
          <div class="helplinks">
            <ul>
              <li><a href="defective_claims.php">Defective Parts</a></li>
              <li><a href="damage_part.php">Damaged Parts</a></li>
              <li><a href="warranty_policy.php">Warranty Policy</a></li>
              <li><a href="return_process.php">Return Process</a></li>
              <li><a href="fitment_issue.php">Fitment Issue</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
              <li><a href="customer_support.php">Customer Support</a></li>
              <li><a href="javascript:void(0)">Part Inquiry</a></li>
              <li><a href="javascript:void(0)">Shippment Policy</a></li>
              <li><a href="about-us.php">About Us</a></li>
              <li><a href="javascript:void(0)">Reviews</a></li>
              <li><a href="privacy_policy.php">Privacy Policy</a></li>
              <li><a href="price_match.php">Price Match</a></li>
              <li><a href="pick_up_availability.php">Pick Up Availability</a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- END Contact Us -->
  <?php include 'includes/footer.php'; ?>