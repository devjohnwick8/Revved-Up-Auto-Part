  <?php include 'includes/header.php'; ?>
  <!-- banner start -->
  <section class="inner_banner">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner_text black_bg">
            <h1>Customer Support</h1>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- banner end -->
  <!-- BEGIN Contact Us -->
  <section id="testimonials padd1">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="gettouch">
          <span>For any return, please Call Us directly or submit a Return Form</span>
          </div>
          <div class="quistionbtn">
            <a href="tel:8882973077"> <i class="fas fa-phone-alt"></i> 888-297-3077</a>
            <a href="submit_returns.php">Submit Returns </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- END Contact Us -->
  <?php include 'includes/footer.php'; ?>