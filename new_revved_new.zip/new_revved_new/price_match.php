  <?php include 'includes/header.php'; ?>
  <!-- banner start -->
  <section class="inner_banner">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner_text black_bg">
            <h1>Price Match</h1>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- banner end -->
  <!-- speedy_sec start  -->

  <!-- speedy_sec start  -->
  <!-- BEGIN About Us -->
  <section class="AboutUsMain">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="AboutContent">
            <h6>Price Match</h6>
            <p>Simply call or send us a message of the ‘Name of competitor’ or enter the URL of our competitors website and then identify SKU or part number of the item, along with the Price and then give us your vehicle information.
              We will only price match to certified and approved stores such as: Napa, Advance Auto, along with other sites that sell high quality auto parts that meet or exceed the OEM.
            </p>
          </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="Aboutimg">
            <img src="images/pr.png" alt="" class="img-fluid">
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- END About Us -->
  <?php include 'includes/footer.php'; ?>