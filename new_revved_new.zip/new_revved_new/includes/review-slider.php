    <section class="re_sec">
      <div class="container">
        <div class="row">
          <h2>Revved Up Reviews</h2>
          <div class="clearfix"></div>
          <div class="col-xs-10 col-sm-10 col-md-10 centerCol">
            <!-- <img src="images/re_1.jpg" class="img-fluid one" alt="">
            <img src="images/re_3.jpg" class="img-fluid three" alt=""> -->
            <div class="blogslid">
              <div>
                <div class="reveiw_text text-center">
                  <img src="images/re_1.jpg" class="img-fluid" alt="">
                  <h4>Where do I start? You can tell this company CARES! Robert has worked closely with my partner and I for the last two years to build the car of our dreams. He was persistent with sourcing exactly what we were looking for and kept us well under budget. The entire team made us feel like family from the beginning. If I could give this place a 10 out of 10 I would. We are definitely customers for LIFE! Thank you again for your outstanding customer service. To potential customers, If you go elsewhere, you’re missing out! Will update with photos soon!</h4>
                  <h3>Stephanie Grinnell </h3>
                </div>
              </div>
              <div>
                <div class="reveiw_text text-center">
                  <img src="images/re_2.jpg" class="img-fluid" alt="">
                  <h4>Where do I start? You can tell this company CARES! Robert has worked closely with my partner and I for the last two years to build the car of our dreams. He was persistent with sourcing exactly what we were looking for and kept us well under budget. The entire team made us feel like family from the beginning. If I could give this place a 10 out of 10 I would. We are definitely customers for LIFE! Thank you again for your outstanding customer service. To potential customers, If you go elsewhere, you’re missing out! Will update with photos soon!</h4>
                  <h3>Stephanie Grinnell </h3>
                </div>
              </div>
              <div>
                <div class="reveiw_text text-center">
                  <img src="images/re_3.jpg" class="img-fluid" alt="">
                  <h4>Where do I start? You can tell this company CARES! Robert has worked closely with my partner and I for the last two years to build the car of our dreams. He was persistent with sourcing exactly what we were looking for and kept us well under budget. The entire team made us feel like family from the beginning. If I could give this place a 10 out of 10 I would. We are definitely customers for LIFE! Thank you again for your outstanding customer service. To potential customers, If you go elsewhere, you’re missing out! Will update with photos soon!</h4>
                  <h3>Stephanie Grinnell </h3>
                </div>
              </div>
              <div>
                <div class="reveiw_text text-center">
                  <img src="images/re_4.jpg" class="img-fluid" alt="">
                  <h4>Where do I start? You can tell this company CARES! Robert has worked closely with my partner and I for the last two years to build the car of our dreams. He was persistent with sourcing exactly what we were looking for and kept us well under budget. The entire team made us feel like family from the beginning. If I could give this place a 10 out of 10 I would. We are definitely customers for LIFE! Thank you again for your outstanding customer service. To potential customers, If you go elsewhere, you’re missing out! Will update with photos soon!</h4>
                  <h3>Stephanie Grinnell </h3>
                </div>
              </div>
              <div>
                <div class="reveiw_text text-center">
                  <img src="images/re_5.jpg" class="img-fluid" alt="">
                  <h4>Where do I start? You can tell this company CARES! Robert has worked closely with my partner and I for the last two years to build the car of our dreams. He was persistent with sourcing exactly what we were looking for and kept us well under budget. The entire team made us feel like family from the beginning. If I could give this place a 10 out of 10 I would. We are definitely customers for LIFE! Thank you again for your outstanding customer service. To potential customers, If you go elsewhere, you’re missing out! Will update with photos soon!</h4>
                  <h3>Stephanie Grinnell </h3>
                </div>
              </div>
            </div>
            <!-- <img src="images/re_4.jpg" class="img-fluid four" alt="">
            <img src="images/re_5.jpg" class="img-fluid five" alt=""> -->
          </div>
        </div>
      </div>
    </section>